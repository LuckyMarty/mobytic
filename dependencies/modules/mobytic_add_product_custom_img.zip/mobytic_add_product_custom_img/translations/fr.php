<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{mobytic_add_product_custom_img}prestashop>mobytic_add_product_custom_img_8e6dd720c38f05e75afa5ea139d43b8b'] = 'Fond personnalisé';
$_MODULE['<{mobytic_add_product_custom_img}prestashop>mobytic_add_product_custom_img_b92e218ab54cf7de49d9aa6632d48cc4'] = 'Permet de choisir l\'image d\'arrière-plan pour chaque page de produit	';
$_MODULE['<{mobytic_add_product_custom_img}prestashop>mobytic_add_product_custom_img_deb10517653c255364175796ace3553f'] = 'Produit';
$_MODULE['<{mobytic_add_product_custom_img}prestashop>mobytic_add_product_custom_img_f4f70727dc34561dfde1a3c529b6205c'] = 'Paramètres';
$_MODULE['<{mobytic_add_product_custom_img}prestashop>mobytic_add_product_custom_img_b9987a246a537f4fe86f1f2e3d10dbdb'] = 'Afficher';
$_MODULE['<{mobytic_add_product_custom_img}prestashop>mobytic_add_product_custom_img_ea9df7a306e2f8b5af37b67084d0c984'] = 'Utiliser ce module en mode direct	';
$_MODULE['<{mobytic_add_product_custom_img}prestashop>mobytic_add_product_custom_img_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Activé';
$_MODULE['<{mobytic_add_product_custom_img}prestashop>mobytic_add_product_custom_img_b9f5c797ebbf55adccdd8539a65a0241'] = 'Désactivé';
$_MODULE['<{mobytic_add_product_custom_img}prestashop>mobytic_add_product_custom_img_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';
$_MODULE['<{mobytic_add_product_custom_img}prestashop>configure_dab718daf821e4b20bcb5a0d6b6a3a81'] = 'Ajouter un fond personnalisé dans la page du produit	';
$_MODULE['<{mobytic_add_product_custom_img}prestashop>mobytic_abd809c9e3c1c08e97740f86b8ceabfb'] = 'Image de fond	';
